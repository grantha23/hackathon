import React, { useState } from 'react';
import * as XLSX from 'xlsx';
import Header from './Header';
import Sidebar from './Sidebar';

const BillGeneration = () => {
  // Sales invoice state
  const [salesInvoice, setSalesInvoice] = useState({
    number: '',
    date: '',
    billTo: '',
    items: []
  });

  // Sales item state
  const [salesItem, setSalesItem] = useState({
    name: '',
    qty: '',
    price: ''
  });

  // Purchasing invoice state
  const [purchaseInvoice, setPurchaseInvoice] = useState({
    number: '',
    date: '',
    billTo: '',
    items: []
  });

  // Purchasing item state
  const [purchaseItem, setPurchaseItem] = useState({
    name: '',
    qty: '',
    price: ''
  });

  // Handle sales item addition
  const addSalesItem = () => {
    const { name, qty, price } = salesItem;
    if (name && qty && price) {
      setSalesInvoice((prevState) => ({
        ...prevState,
        items: [...prevState.items, { name, qty, price: parseFloat(price).toFixed(2) }]
      }));

      // Clear sales item fields
      setSalesItem({ name: '', qty: '', price: '' });
    }
  };

  // Handle purchase item addition
  const addPurchaseItem = () => {
    const { name, qty, price } = purchaseItem;
    if (name && qty && price) {
      setPurchaseInvoice((prevState) => ({
        ...prevState,
        items: [...prevState.items, { name, qty, price: parseFloat(price).toFixed(2) }]
      }));

      // Clear purchase item fields
      setPurchaseItem({ name: '', qty: '', price: '' });
    }
  };

  // Calculate total for sales invoice
  const calculateSalesTotal = () => {
    const total = salesInvoice.items.reduce((acc, item) => acc + item.qty * item.price, 0);
    return total.toFixed(2);
  };

  // Calculate total for purchase invoice
  const calculatePurchaseTotal = () => {
    const total = purchaseInvoice.items.reduce((acc, item) => acc + item.qty * item.price, 0);
    return total.toFixed(2);
  };

  // Export sales data to Excel
  const exportSalesToExcel = () => {
    const ws = XLSX.utils.json_to_sheet(getSalesData());
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sales Invoice');
    XLSX.writeFile(wb, 'Sales_Invoice.xlsx');
  };

  // Export purchase data to Excel
  const exportPurchaseToExcel = () => {
    const ws = XLSX.utils.json_to_sheet(getPurchaseData());
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Purchasing Invoice');
    XLSX.writeFile(wb, 'Purchasing_Invoice.xlsx');
  };

  // Gather sales invoice data for export
  const getSalesData = () => {
    return salesInvoice.items.map((item) => ({
      'Item Name': item.name,
      'Quantity': item.qty,
      'Price': item.price,
      'Invoice Number': salesInvoice.number,
      'Date': salesInvoice.date,
      'Bill To': salesInvoice.billTo
    }));
  };

  // Gather purchase invoice data for export
  const getPurchaseData = () => {
    return purchaseInvoice.items.map((item) => ({
      'Item Name': item.name,
      'Quantity': item.qty,
      'Price': item.price,
      'Invoice Number': purchaseInvoice.number,
      'Date': purchaseInvoice.date,
      'Bill To': purchaseInvoice.billTo
    }));
  };

  return (
    <div>
      <Header />
      <main>
        <Sidebar />
        <div className="main-content">
        <h1>Generate Your Bill</h1>
        {/* Sales Invoice Section */}
        <div className="invoice-section">
          <h2>Sales Invoice</h2>
          <input
            type="text"
            value={salesInvoice.number}
            onChange={(e) => setSalesInvoice({ ...salesInvoice, number: e.target.value })}
            placeholder="Invoice Number"
            required
          />
          <input
            type="date"
            value={salesInvoice.date}
            onChange={(e) => setSalesInvoice({ ...salesInvoice, date: e.target.value })}
            required
          />
          <textarea
            value={salesInvoice.billTo}
            onChange={(e) => setSalesInvoice({ ...salesInvoice, billTo: e.target.value })}
            placeholder="Bill To"
            required
          ></textarea>

          <div id="salesItemsList">
            {salesInvoice.items.map((item, index) => (
              <div key={index}>{item.name} - Qty: {item.qty}, Price: ${item.price}</div>
            ))}
          </div>

          <div className="item-row">
            <input
              type="text"
              value={salesItem.name}
              onChange={(e) => setSalesItem({ ...salesItem, name: e.target.value })}
              placeholder="Item Name"
              required
            />
            <input
              type="number"
              value={salesItem.qty}
              onChange={(e) => setSalesItem({ ...salesItem, qty: e.target.value })}
              min="1"
              placeholder="Qty"
              required
            />
            <input
              type="number"
              value={salesItem.price}
              onChange={(e) => setSalesItem({ ...salesItem, price: e.target.value })}
              min="0.01"
              step="0.01"
              placeholder="Price"
              required
            />
            <button type="button" onClick={addSalesItem}>Add Item</button>
          </div>

          <button type="button" onClick={calculateSalesTotal}>
            Calculate Total
          </button>
          <div id="salesTotal" className="total">Total: ${calculateSalesTotal()}</div>
          <button type="button" onClick={exportSalesToExcel}>Export Sales Invoice to Excel</button>
        </div>

        {/* Purchasing Invoice Section */}
        <div className="invoice-section">
          <h2>Purchasing Invoice</h2>
          <input
            type="text"
            value={purchaseInvoice.number}
            onChange={(e) => setPurchaseInvoice({ ...purchaseInvoice, number: e.target.value })}
            placeholder="Invoice Number"
            required
          />
          <input
            type="date"
            value={purchaseInvoice.date}
            onChange={(e) => setPurchaseInvoice({ ...purchaseInvoice, date: e.target.value })}
            required
          />
          <textarea
            value={purchaseInvoice.billTo}
            onChange={(e) => setPurchaseInvoice({ ...purchaseInvoice, billTo: e.target.value })}
            placeholder="Bill To"
            required
          ></textarea>

          <div id="purchaseItemsList">
            {purchaseInvoice.items.map((item, index) => (
              <div key={index}>{item.name} - Qty: {item.qty}, Price: ${item.price}</div>
            ))}
          </div>

          <div className="item-row">
            <input
              type="text"
              value={purchaseItem.name}
              onChange={(e) => setPurchaseItem({ ...purchaseItem, name: e.target.value })}
              placeholder="Item Name"
              required
            />
            <input
              type="number"
              value={purchaseItem.qty}
              onChange={(e) => setPurchaseItem({ ...purchaseItem, qty: e.target.value })}
              min="1"
              placeholder="Qty"
              required
            />
            <input
              type="number"
              value={purchaseItem.price}
              onChange={(e) => setPurchaseItem({ ...purchaseItem, price: e.target.value })}
              min="0.01"
              step="0.01"
              placeholder="Price"
              required
            />
            <button type="button" onClick={addPurchaseItem}>Add Item</button>
          </div>

          <button type="button" onClick={calculatePurchaseTotal}>
            Calculate Total
          </button>
          <div id="purchaseTotal" className="total">Total: ${calculatePurchaseTotal()}</div>
          <button type="button" onClick={exportPurchaseToExcel}>Export Purchase Invoice to Excel</button>
        </div>
        </div>
      </main>
    </div>
  );
};

export default BillGeneration;
