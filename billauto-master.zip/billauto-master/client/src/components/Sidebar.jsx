import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const Sidebar = () => {
  const [activeLink, setActiveLink] = useState('Info');

  const handleLinkClick = (linkName) => {
    setActiveLink(linkName);
  };

  return (
    <aside className="sidebar">
      <nav>
        <ul>
          <li>
            <Link
              to="/"
              className={activeLink === 'Info' ? 'active' : ''}
              onClick={() => handleLinkClick('Info')}
            >
              Info
            </Link>
          </li>
          <li>
            <Link
              to="/InventoryManagement" // Assuming this should be a route like '/inventory-tracking'
              className={activeLink === 'Inventory Tracking' ? 'active' : ''}
              onClick={() => handleLinkClick('Inventory Tracking')}
            >
              Inventory Tracking
            </Link>
          </li>
          <li>
            <Link
              to="/BillGeneration"
              className={activeLink === 'Bill Generation' ? 'active' : ''}
              onClick={() => handleLinkClick('Bill Generation')}
            >
              Bill Generation
            </Link>
          </li>
          <li>
            <Link
              to="/settings"
              className={activeLink === 'Settings' ? 'active' : ''}
              onClick={() => handleLinkClick('Settings')}
            >
              Settings
            </Link>
          </li>
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;
