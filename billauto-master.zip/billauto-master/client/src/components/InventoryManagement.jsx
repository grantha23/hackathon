import React, { useState, useEffect } from 'react';
import $ from 'jquery';
import 'datatables.net';
import Chart from 'chart.js/auto';
import LowStockAlert from './LowStockAlert';
import Header from './Header'; 
import Sidebar from './Sidebar';

const InventoryManagement = () => {
    const [inventoryData, setInventoryData] = useState([]);
    const [itemName, setItemName] = useState('');
    const [itemQuantity, setItemQuantity] = useState('');
    const [itemPrice, setItemPrice] = useState('');
    const [showChart, setShowChart] = useState(false);
    let inventoryChart = null; // Variable to hold the chart instance

    // UseEffect to update the chart when showChart is toggled and inventoryData changes
    useEffect(() => {
        if (showChart) {
            updateChart(); // Update the chart when the chart is shown and data changes
        }
    }, [showChart, inventoryData]); // Dependencies: re-run when showChart or inventoryData changes

    const updateTable = () => {
        $('#inventoryTable').DataTable().clear().destroy(); // Destroy the previous DataTable instance
        $('#inventoryData').empty();

        inventoryData.forEach((data) => {
            $('#inventoryData').append(`
                <tr>
                    <td>${data.item}</td>
                    <td>${data.quantity}</td>
                    <td>${data.price}</td>
                </tr>
            `);
        });

        $('#inventoryTable').DataTable(); // Re-initialize DataTable
    };

    const updateChart = () => {
        const ctx = document.getElementById('inventoryChart');
        if (ctx) {
            const chartContext = ctx.getContext('2d');
            const labels = inventoryData.map((data) => data.item);
            const quantities = inventoryData.map((data) => data.quantity);
    
            // Check if there's already an existing chart instance and destroy it
            if (inventoryChart !== null) {
                inventoryChart.destroy();
            }
    
            // Create a new chart instance
            inventoryChart = new Chart(chartContext, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [
                        {
                            label: 'Inventory Quantity',
                            data: quantities,
                            backgroundColor: 'rgba(75, 192, 192, 0.2)',
                            borderColor: 'rgba(75, 192, 192, 1)',
                            borderWidth: 1,
                        },
                    ],
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true,
                        },
                    },
                },
            });
        }
    };
    

    const handleFormSubmit = (event) => {
        event.preventDefault();
        const newItem = {
            item: itemName,
            quantity: parseInt(itemQuantity),
            price: parseFloat(itemPrice),
        };

        setInventoryData([...inventoryData, newItem]);

        // Clear input fields
        setItemName('');
        setItemQuantity('');
        setItemPrice('');
    };

    const handleShowChart = () => {
        setShowChart(!showChart);
    };

    const handleFileImport = (event) => {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                const contents = e.target.result;
                console.log(contents); // For now, just log the contents to the console
                alert('File imported successfully!');
                // Here you can parse the contents and add it to inventoryData if needed.
            };
            reader.readAsText(file); // Read file as text (assuming CSV or similar format)
        }
    };

    const handleFetchData = () => {
        // Simulate fetching data from a server
        const fetchedData = [
            { item: 'Grapes', quantity: 25, price: 0.4 },
            { item: 'Pineapples', quantity: 10, price: 1.5 },
            { item: 'Mangoes', quantity: 5, price: 1.2 },
        ];

        setInventoryData([...inventoryData, ...fetchedData]);
        alert('Data fetched successfully!');
    };

    return (
        <div className="container">
            <Header />
            <main>
                <Sidebar />
                <div className="main-content">
                    <h1>Real-Time Inventory Management</h1>

                    {/* User Input Form */}
                    <form onSubmit={handleFormSubmit}>
                        <input
                            type="text"
                            value={itemName}
                            onChange={(e) => setItemName(e.target.value)}
                            placeholder="Item Name"
                            required
                        />
                        <input
                            type="number"
                            value={itemQuantity}
                            onChange={(e) => setItemQuantity(e.target.value)}
                            placeholder="Quantity"
                            required
                        />
                        <input
                            type="number"
                            value={itemPrice}
                            onChange={(e) => setItemPrice(e.target.value)}
                            placeholder="Price"
                            required
                        />
                        <button type="submit">Add Item</button>
                        <button type="button" onClick={handleShowChart}>
                            {showChart ? 'Hide Chart' : 'Show Chart'}
                        </button>
                        <input
                            type="file"
                            id="fileInput"
                            style={{ display: 'none' }}
                            onChange={handleFileImport}
                        />
                        <button type="button" onClick={() => document.getElementById('fileInput').click()}>
                            Import
                        </button>
                        <button type="button" onClick={handleFetchData}>
                            Fetch Data
                        </button>
                    </form>

                    {showChart && <canvas id="inventoryChart" width="400" height="200"></canvas>}

                    <table id="inventoryTable" className="display">
                        <thead>
                            <tr>
                                <th>Item</th>
                                <th>Quantity</th>
                                <th>Price</th>
                            </tr>
                        </thead>
                        <tbody id="inventoryData">
                            {/* Dynamic data will be injected here */}
                        </tbody>
                    </table>
                    <LowStockAlert />
                </div>
            </main>
        </div>
    );
};

export default InventoryManagement;
