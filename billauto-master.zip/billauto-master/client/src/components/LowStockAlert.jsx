import React from 'react';

const LowStockAlert = () => {
  const threshold = 10; // Set the stock threshold

  const checkStock = () => {
    const rows = document.querySelectorAll('#stockTable tbody tr');
    rows.forEach((row) => {
      const quantity = parseInt(row.cells[1].textContent);
      if (quantity <= threshold) {
        row.classList.add('low-stock');
        alert(`Low stock alert for ${row.cells[0].textContent}!`);
      } else {
        row.classList.remove('low-stock');
      }
    });
  };

  const importFile = (event) => {
    const file = event.target.files[0];
    if (file) {
      // Here you can implement file reading logic
      alert('File imported successfully!');
    }
  };

  const fetchData = () => {
    const apiUrl = 'https://jsonplaceholder.typicode.com/posts'; // Replace with your actual API URL
    fetch(apiUrl)
      .then((response) => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then((data) => {
        console.log(data); // Process the fetched data as needed
        alert('Data fetched successfully! Check the console for details.');
      })
      .catch((error) => {
        console.error('Fetch error:', error);
        alert('Failed to fetch data. Check console for details.');
      });
  };

  const openModal = () => {
    document.getElementById('myModal').style.display = 'block';
    document.getElementById('error-message').innerText = ''; // Clear previous error messages
  };

  const closeModal = () => {
    document.getElementById('myModal').style.display = 'none';
  };

  const addStock = () => {
    const productName = document.getElementById('productName').value.trim();
    const quantity = parseInt(document.getElementById('quantity').value);

    // Validate input
    if (productName === '') {
      document.getElementById('error-message').innerText = 'Please enter a product name.';
      return;
    }

    if (isNaN(quantity) || quantity <= 0) {
      document.getElementById('error-message').innerText = 'Please enter a valid quantity.';
      return;
    }

    const tableBody = document.querySelector('#stockTable tbody');
    const newRow = document.createElement('tr');
    newRow.innerHTML = `<td>${productName}</td><td>${quantity}</td>`;
    tableBody.appendChild(newRow);

    closeModal(); // Close modal after adding
    checkStock(); // Recheck stock after adding
  };

  // Check stock on page load
  React.useEffect(() => {
    checkStock();
  }, []);

  return (
    <div className="low-stock-alert">
      <h1>Low Stock Alert</h1>

      <div style={{ textAlign: 'center' }}>
        <button className="import-button" onClick={() => document.getElementById('fileInput').click()}>
          Import Stock List
        </button>
        <input
          type="file"
          id="fileInput"
          style={{ display: 'none' }}
          onChange={importFile}
        />

        <button className="fetch-button" onClick={fetchData}>
          Fetch Data
        </button>

        <button className="add-button" onClick={openModal}>
          Add Stock
        </button>
      </div>

      <table id="stockTable">
        <thead>
          <tr>
            <th>Product Name</th>
            <th>Quantity</th>
          </tr>
        </thead>
        <tbody>
          {/* No sample data, table starts empty */}
        </tbody>
      </table>

      {/* Modal for adding stock */}
      <div id="myModal" className="modal">
        <div className="modal-content">
          <span onClick={closeModal} style={{ cursor: 'pointer', float: 'right' }}>
            &times;
          </span>
          <h2>Add Stock</h2>

          <label htmlFor="productName">Product Name:</label>
          <br />
          <input type="text" id="productName" placeholder="Enter product name" required />
          <br />
          <br />

          <label htmlFor="quantity">Quantity:</label>
          <br />
          <input type="number" id="quantity" min="1" placeholder="Enter quantity" required />
          <br />
          <br />

          <button onClick={addStock}>Add</button>
          <p id="error-message"></p> {/* Error message display */}
        </div>
      </div>
    </div>
  );
};

export default LowStockAlert;
