import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import Header from './Header';

const Login = () => {
  const [formData, setFormData] = useState({
    type: 'User', // Default selection
    Email: '',    // Changed to Email
    Password: ''
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
  
    const { type, Email, Password } = formData; // Extract form data
  
    try {
      const response = await axios.post('http://localhost:5000/login', { type, Email, Password });
  
      if (response.status === 200) {
        const { type, email, name, doctorName, hospitalName, hospitalId } = response.data;

        sessionStorage.setItem('userType', type);
        sessionStorage.setItem('userEmail', email);
        sessionStorage.setItem('displayName', name || email);
        alert('Login successful!');
        navigate('/'); // Adjust to appropriate route for User
      } else {
        alert('Login failed. Please check your credentials.');
      }
    } catch (error) {
      console.error('There was an error logging in!', error);
      alert('Login failed due to a server error.');
    }
  };
  

  return (
    <div className="container">
      <Header />
      <div className="heading">Sign In</div>
      <form onSubmit={handleSubmit} className="form">
        <input 
          type="email" 
          className="input" 
          name="Email" // Changed to Email
          placeholder="E-mail" 
          value={formData.Email}
          onChange={handleChange}
          required 
        />
        <input 
          type="password" 
          className="input" 
          name="Password"  
          placeholder="Password" 
          value={formData.Password}
          onChange={handleChange}
          required 
        />
        <input 
          className="login-button" 
          type="submit" 
          value="Sign In" 
        />
      </form>
      <span className="agreement">
        <a href="#">Learn about the user license agreement</a>
      </span>
    </div>
  );
}

export default Login;