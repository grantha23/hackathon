import React, { useState } from 'react';  // Add useState here
import { Routes, Route, BrowserRouter } from 'react-router-dom';  // Import BrowserRouter
import './App.css';

import Header from './components/Header'; // Import the Header component
import Login from './components/Login';
import Register from './components/Register';
import Sidebar from './components/Sidebar';
import BillGeneration from './components/BillGeneration';
import InventoryManagement from './components/InventoryManagement';

function Home() {
  // State to hold inventory items
  const [inventory, setInventory] = useState([]);

  // State to hold new row inputs
  const [newItem, setNewItem] = useState({ item: '', quantity: '', warehouse: '' });

  // State for alerts
  const [alerts, setAlerts] = useState([]);

  // Function to add a new row to the inventory
  const addRow = (e) => {
    e.preventDefault();
    if (newItem.item && newItem.quantity && newItem.warehouse) {
      const updatedInventory = [...inventory, { ...newItem, quantity: parseInt(newItem.quantity, 10) }];
      setInventory(updatedInventory);
      checkLowStock(newItem);
      // Clear input fields after adding
      setNewItem({ item: '', quantity: '', warehouse: '' });
    } else {
      alert('Please fill all fields before adding.');
    }
  };

  // Check low stock and generate alert
  const checkLowStock = (item) => {
    if (parseInt(item.quantity, 10) < 10) {
      setAlerts([...alerts, `${item.item} is low on stock`]);
    }
  };

  // Function to handle form inputs for each field
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewItem({ ...newItem, [name]: value });
  };

  return (
    <div>
      <Header />
      <main>
      <Sidebar />
      
      <div className="main-content">
        <section id="inventory">
          <h2>Inventory Tracking</h2>
          <form onSubmit={addRow}>
            <table id="inventoryTable">
              <thead>
                <tr>
                  <th>Item</th>
                  <th>Quantity</th>
                  <th>Warehouse</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {inventory.map((inv, index) => (
                  <tr key={index}>
                    <td>{inv.item}</td>
                    <td>{inv.quantity}</td>
                    <td>{inv.warehouse}</td>
                  </tr>
                ))}
                {/* Input row */}
                <tr>
                  <td>
                    <input
                      type="text"
                      name="item"
                      value={newItem.item}
                      onChange={handleInputChange}
                      placeholder="Item Name"
                      required
                    />
                  </td>
                  <td>
                    <input
                      type="number"
                      name="quantity"
                      value={newItem.quantity}
                      onChange={handleInputChange}
                      placeholder="Quantity"
                      required
                    />
                  </td>
                  <td>
                    <input
                      type="text"
                      name="warehouse"
                      value={newItem.warehouse}
                      onChange={handleInputChange}
                      placeholder="Warehouse"
                      required
                    />
                  </td>
                  <td>
                    <button type="submit">Add Row</button>
                  </td>
                </tr>
              </tbody>
            </table>
          </form>
        </section>

        {/* Low Stock Alerts */}
        <section id="alerts">
          <h2>Low Stock Alerts</h2>
          <div id="alertBox">
            {alerts.map((alert, index) => (
              <p key={index}>{alert}</p>
            ))}
          </div>
        </section>
        
</div>
      </main>
    </div>
  );
}

function App() {
  return (
    <BrowserRouter>  {/* Wrap your Routes in BrowserRouter */}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/BillGeneration" element={<BillGeneration />} />
        <Route path="/InventoryManagement" element={<InventoryManagement />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
