const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

mongoose.connection.on('connected', () => {
  console.log('Connected to MongoDB');
});

mongoose.connection.on('error', (err) => {
  console.error(`Error connecting to MongoDB: ${err}`);
});

// Status route
app.get('/status', (req, res) => {
  res.status(200).json({ message: 'Server Online' });
});

// Import User model
const User = require('./models/User');

// Register route
app.post('/register', async (req, res) => {
  try {
    const { type, Name, ContactNumber, Email, Address, Password, Specialization } = req.body;
    const hashedPassword = await bcrypt.hash(Password, 10);

    let existingUser = await User.findOne({ Email });
    if (existingUser) {
      return res.status(400).json({ message: 'Email already exists' });
    }

    const newUser = new User({
      Name,
      ContactNumber,
      Email,
      Address,
      Password: hashedPassword,
      Specialization,
    });

    await newUser.save();
    res.status(201).json({ message: `${type} registered successfully` });
  } catch (error) {
    console.error('Error during registration:', error);
    res.status(500).json({ message: 'Error during registration', error: error.message });
  }
});

// Login route
app.post('/login', async (req, res) => {
  try {
    const { type, Email, Password } = req.body;
    let user = await User.findOne({ Email });

    if (!user) return res.status(400).json({ message: `${type} not found (Login Failed)` });

    const match = await bcrypt.compare(Password, user.Password);
    if (!match) return res.status(400).json({ message: 'Invalid credentials' });

    // Generate JWT token
    const token = jwt.sign({ id: user._id, email: user.Email }, process.env.JWT_SECRET, { expiresIn: '1h' });

    res.status(200).json({
      message: 'Login successful',
      token: token,
      type: 'Welcome',
    });
  } catch (error) {
    console.error('Error logging in:', error);
    res.status(500).json({ message: 'Error logging in', error });
  }
});

// Import Inventory routes
const inventoryRoutes = require('./routes/inventory');
app.use('/api/inventory', inventoryRoutes);

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
